﻿using System;
using System.Collections.Generic;
using AnagramCheckerLibrary;
using Microsoft.Extensions.Configuration;

namespace AnagramCheckerConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            if (args[0] == "check" && args[1] != null && args[2] != null)
            {
                checkTwoWords(args);
            }
            if (args[0] == "getKnown" && args[1] != null)
            {
                checkWordsFromDictionary(args);
            }
        }

        private static void checkWordsFromDictionary(string[] args)
        {
            DictionaryFileReader reader = new DictionaryFileReader();
            if (args[1] == "" || args[1] == null)
            {
                Console.WriteLine("Add a word to the query");
            }
            var anagramDict = reader.ReadDictionary("Dictionary.csv");
            List<string> list = new List<string>();
            foreach (string entry in anagramDict)
            {
                list.Add(entry);
            }
            AnagramChecker checker = new AnagramChecker();
            var words = checker.GetWordToCheck(list, args[1].ToString());

            if (words.ToString().Length == 0)
            {
                Console.WriteLine(args[1] + " not Found");
            }
            else
            {
                Console.WriteLine("Known Anagrams: " + words);
            }
           
        }

        private static void checkTwoWords(string[] args)
        {
            AnagramChecker checker = new AnagramChecker();
            bool check = checker.CheckTwoWords(args[1], args[2]);
            if (check)
            {
                Console.WriteLine(args[1] + " " + args[2] + " are anagrams");
            }
            else
            {
                Console.WriteLine(args[1] + " " + args[2] + " are no anagrams");
            }
        }

        private static IConfigurationBuilder GetConfiguration()
        {
            var environmentName = Environment.GetEnvironmentVariable("Hosting:Environment");
            return new ConfigurationBuilder()
                .AddJsonFile("appsettings.json")
                .AddJsonFile($"appsettings.{environmentName}.json", true)
                .AddEnvironmentVariables();
        }
    }
}
