﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using AnagramCheckerLibrary;

namespace AnagramCheckerAPI.Controllers
{
    [ApiController]
    [Route("api")]
    public class AnagramChecker : ControllerBase
    {
        private readonly IDictionaryReader reader;
        private readonly IAnagramChecker checker;

        public AnagramChecker(IDictionaryReader reader, IAnagramChecker checker)
        {
            this.reader = reader;
            this.checker = checker;
        }

        [HttpGet]
        [Route("checkAnagram")]
        public IActionResult SpellCheck([FromBody]string words)
        {
            string word1 = words.Split('-').First();
            string word2 = words.Split('-').Last();

            bool check = checker.CheckTwoWords(word1, word2);
            if (check)
            {
                return Ok(word1 + " " + word2 + " are anagrams");
            }
            else
            {
                return BadRequest(word1 + " " + word2 + " are no anagrams");
            }
        }

        [HttpGet]
        [Route("getKnownWords")]
        public IActionResult GetKnownWords([FromQuery]string word)
        {
            if (word == "" || word == null)
            {
                return NotFound("Please add a word the the query");
            }
            var anagramDict = reader.ReadDictionary("Dictionary.csv");
            List<string> list = new List<string>();
            foreach(string entry in anagramDict)
            {
                list.Add(entry);
            }
            var words = checker.GetWordToCheck(list, word);
            
            if (words.Count() == 0)
            {
                return NotFound(word + " not Found");
            }
            return Ok("Known Anagrams: " + words);
        }

    }
}
