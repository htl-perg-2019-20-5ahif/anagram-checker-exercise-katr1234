﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AnagramCheckerLibrary
{
    public interface IAnagramChecker
    {
        IEnumerable<string> GetWordToCheck(List<string> dictionaryList, string wordToCheck);

        bool CheckTwoWords(string word1, string word2);
    }
}
