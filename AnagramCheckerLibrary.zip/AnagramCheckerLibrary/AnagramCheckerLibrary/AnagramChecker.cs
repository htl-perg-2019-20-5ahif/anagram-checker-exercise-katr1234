﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AnagramCheckerLibrary
{
    public class AnagramChecker : IAnagramChecker
    {
        public bool CheckTwoWords(string word1, string word2)
        {
            string sortedWord1 = SortArray(word1);
            string sortedWord2 = SortArray(word2);

            if (sortedWord1.Equals(sortedWord2))
            {
                return true;
            }
            return false;
        }

        public IEnumerable<string> GetWordToCheck(List<string> dictionaryList, string wordToCheck)
        {
            foreach(string row in dictionaryList)
            {
                var rowList = row.Split(',');

                for (int i = 0; i < rowList.Length; i++)
                {
                    if(CheckTwoWords(rowList[i], wordToCheck))
                    {
                        return rowList;
                    }
                }
            }
            return null;
        }

        private string SortArray(string word) 
        {
            char[] charWord = word.ToCharArray();
            Array.Sort(charWord);

            return new string(charWord);

        }
    }
}
