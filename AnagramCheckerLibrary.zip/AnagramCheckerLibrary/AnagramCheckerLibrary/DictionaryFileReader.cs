﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AnagramCheckerLibrary
{
    public class DictionaryFileReader : IDictionaryReader
    {
        public IEnumerable<string> ReadDictionary(String path)
        {
            // Read the file as one string
            var dictionaryFile = System.IO.File.ReadAllText(path);

            // Save the String in a List
            var list = dictionaryFile.Split('\n');

            // Return the List
            return list;
        }
    }
}
