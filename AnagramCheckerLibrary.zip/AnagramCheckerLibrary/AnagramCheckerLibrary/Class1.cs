﻿using System;

namespace AnagramCheckerLibrary
{
    public class Class1
    {
        DictionaryFileReader reader = new DictionaryFileReader();
        AnagramChecker checker = new AnagramChecker();



    }
}
