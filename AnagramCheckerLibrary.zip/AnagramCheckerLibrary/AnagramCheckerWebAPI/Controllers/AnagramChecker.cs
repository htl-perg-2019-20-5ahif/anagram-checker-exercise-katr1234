﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace AnagramCheckerWebAPI.Controllers
{
    [ApiController]
    [Route("api/anagramChecker")]
    public class AnagramChecker : ControllerBase
    {
        
        [HttpPost]
        public IEnumerable<string> SpellCheck([FromBody] string anagram)
        {
            return new List<string>();
        }
    }
}
